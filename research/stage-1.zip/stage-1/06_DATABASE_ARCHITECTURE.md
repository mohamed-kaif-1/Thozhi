# 06 — Database Architecture & Relational Schema Specification

## 1. Executive Summary & Technology Stack
- **Database Engine:** PostgreSQL 15+ hosted on Supabase Cloud (`ap-south-1` Mumbai Region).
- **ORM / Driver:** SQLAlchemy 2.0 (Async) + `asyncpg` for high-throughput asynchronous I/O in FastAPI.
- **Security Paradigm:** 100% Multi-Tenant Isolation enforced via PostgreSQL **Row-Level Security (RLS)** keyed to `auth.uid()`.
- **Schema Migration Strategy:** Version-controlled Alembic migrations (provisional specification only; no migrations executed in Stage 1).

---

## 2. Evaluation of Vector Storage (`pgvector`)

Section 6 of the Master Execution Prompt specifies:
> *"pgvector only if a demonstrated retrieval requirement justifies it."*

### Architectural Evaluation:
1. **MVP Requirements Audit:** The core MVP workflow is strictly operational and deterministic:
   - Capture thought $\rightarrow$ Extract tasks $\rightarrow$ Check calendar availability $\rightarrow$ Present proposal card $\rightarrow$ Commit approved tasks to today's schedule.
   - Retrieval queries in MVP are strictly relational:
     ```sql
     SELECT * FROM saved_tasks 
     WHERE user_id = :uid AND scheduled_date = :target_date 
     ORDER BY scheduled_start ASC;
     ```
2. **Is Semantic Search Required in MVP?** **NO.** Searching unstructured semantic similarity across past notes is a "Nice-to-Have" (P2) feature, not a core requirement for daily planning.
3. **Architectural Verdict on `pgvector`:**  
   $$\mathbf{DEFERRED\ TO\ STAGE\ 2.}$$
   Introducing `pgvector` in the MVP introduces unnecessary embedding model costs, extra memory consumption, and schema complexity with zero contribution to the core planning loop. PostgreSQL B-tree relational indexes cover 100% of MVP requirements.

---

## 3. Entity Relationship Diagram (ERD)

```mermaid
erDiagram
    users ||--o{ user_settings : "configures"
    users ||--o{ raw_captures : "records"
    users ||--o{ task_proposals : "receives"
    users ||--o{ saved_tasks : "owns"
    users ||--o{ user_duration_priors : "accumulates"
    users ||--o{ audit_logs : "generates"
    
    raw_captures ||--o{ task_proposals : "produces"
    task_proposals ||--o| saved_tasks : "promoted to"

    users {
        uuid id PK
        varchar email
        varchar timezone
        time working_hours_start
        time working_hours_end
        timestamptz created_at
    }

    user_settings {
        uuid id PK
        uuid user_id FK
        varchar asr_provider_pref
        boolean learn_durations_opt_in
        int transcript_retention_days
        timestamptz updated_at
    }

    raw_captures {
        uuid id PK
        uuid user_id FK
        varchar input_type
        text transcript_text
        varchar asr_provider
        int audio_duration_sec
        timestamptz created_at
    }

    task_proposals {
        uuid id PK
        uuid capture_id FK
        uuid user_id FK
        text raw_snippet
        varchar proposed_title
        varchar modality
        int estimated_duration_min
        timestamptz target_deadline
        text dependencies
        text conflict_flags
        varchar approval_status
        timestamptz created_at
    }

    saved_tasks {
        uuid id PK
        uuid user_id FK
        uuid proposal_id FK
        varchar title
        date scheduled_date
        time scheduled_start
        time scheduled_end
        int duration_min
        varchar priority
        varchar status
        varchar google_event_id
        timestamptz completed_at
        timestamptz created_at
    }

    user_duration_priors {
        uuid id PK
        uuid user_id FK
        varchar task_keyword
        int sample_count
        int rolling_avg_duration_min
        timestamptz updated_at
    }

    audit_logs {
        uuid id PK
        uuid user_id FK
        varchar event_type
        jsonb metadata
        timestamptz created_at
    }
```

---

## 4. Complete PostgreSQL DDL Specification

```sql
-- ====================================================================
-- THOZHI CORE SCHEMA DDL SPECIFICATION (PostgreSQL 15+)
-- ====================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. ENUM TYPES
CREATE TYPE input_type_enum AS ENUM ('AUDIO', 'TEXT');
CREATE TYPE asr_provider_enum AS ENUM ('GNANI', 'SARVAM', 'MANUAL_TEXT');
CREATE TYPE task_modality_enum AS ENUM (
    'HARD_COMMITMENT', 
    'CASUAL_IDEA', 
    'WISH', 
    'CONDITIONAL_TASK', 
    'COMPLETED_ACTION', 
    'CANCELLED'
);
CREATE TYPE proposal_status_enum AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'POSTPONED');
CREATE TYPE task_priority_enum AS ENUM ('P1_CRITICAL', 'P2_MEDIUM', 'P3_LOW', 'BACKBURNER');
CREATE TYPE task_status_enum AS ENUM ('PENDING', 'IN_PROGRESS', 'COMPLETED', 'POSTPONED', 'CANCELLED');

-- 3. USER PROFILES TABLE (Mirrors Supabase auth.users)
CREATE TABLE users (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL UNIQUE,
    timezone VARCHAR(64) DEFAULT 'Asia/Kolkata' NOT NULL,
    working_hours_start TIME DEFAULT '09:00:00' NOT NULL,
    working_hours_end TIME DEFAULT '18:00:00' NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 4. USER SETTINGS TABLE
CREATE TABLE user_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
    asr_provider_pref asr_provider_enum DEFAULT 'GNANI' NOT NULL,
    learn_durations_opt_in BOOLEAN DEFAULT FALSE NOT NULL,
    transcript_retention_days INT DEFAULT 30 NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 5. RAW CAPTURES TABLE
CREATE TABLE raw_captures (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    input_type input_type_enum NOT NULL,
    transcript_text TEXT NOT NULL,
    asr_provider asr_provider_enum NOT NULL,
    audio_duration_sec INT DEFAULT 0 NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 6. TASK PROPOSALS TABLE
CREATE TABLE task_proposals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    capture_id UUID REFERENCES raw_captures(id) ON DELETE SET NULL,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    raw_snippet TEXT NOT NULL,
    proposed_title VARCHAR(255) NOT NULL,
    modality task_modality_enum NOT NULL,
    estimated_duration_min INT DEFAULT 30 NOT NULL,
    target_deadline TIMESTAMPTZ,
    dependencies TEXT[] DEFAULT '{}'::TEXT[] NOT NULL,
    conflict_flags TEXT[] DEFAULT '{}'::TEXT[] NOT NULL,
    approval_status proposal_status_enum DEFAULT 'PENDING' NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 7. SAVED TASKS TABLE (Approved Items Only)
CREATE TABLE saved_tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    proposal_id UUID REFERENCES task_proposals(id) ON DELETE SET NULL,
    title VARCHAR(255) NOT NULL,
    scheduled_date DATE DEFAULT CURRENT_DATE NOT NULL,
    scheduled_start TIME,
    scheduled_end TIME,
    duration_min INT DEFAULT 30 NOT NULL,
    priority task_priority_enum DEFAULT 'P2_MEDIUM' NOT NULL,
    status task_status_enum DEFAULT 'PENDING' NOT NULL,
    google_event_id VARCHAR(128),
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 8. USER DURATION PRIORS TABLE (Consensual Memory Only)
CREATE TABLE user_duration_priors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_keyword VARCHAR(64) NOT NULL,
    sample_count INT DEFAULT 1 NOT NULL,
    rolling_avg_duration_min INT NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    CONSTRAINT unique_user_keyword UNIQUE (user_id, task_keyword)
);

-- 9. AUDIT LOGS TABLE
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    event_type VARCHAR(64) NOT NULL,
    metadata JSONB DEFAULT '{}'::JSONB NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- ====================================================================
-- PERFORMANCE INDEXES
-- ====================================================================
CREATE INDEX idx_captures_user_id ON raw_captures(user_id, created_at DESC);
CREATE INDEX idx_proposals_user_status ON task_proposals(user_id, approval_status);
CREATE INDEX idx_tasks_user_scheduled ON saved_tasks(user_id, scheduled_date, status);
CREATE INDEX idx_tasks_proposal_id ON saved_tasks(proposal_id);

-- ====================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ====================================================================
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE raw_captures ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_proposals ENABLE ROW LEVEL SECURITY;
ALTER TABLE saved_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_duration_priors ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY users_isolation ON users FOR ALL USING (auth.uid() = id);
CREATE POLICY settings_isolation ON user_settings FOR ALL USING (auth.uid() = user_id);
CREATE POLICY captures_isolation ON raw_captures FOR ALL USING (auth.uid() = user_id);
CREATE POLICY proposals_isolation ON task_proposals FOR ALL USING (auth.uid() = user_id);
CREATE POLICY tasks_isolation ON saved_tasks FOR ALL USING (auth.uid() = user_id);
CREATE POLICY priors_isolation ON user_duration_priors FOR ALL USING (auth.uid() = user_id);
CREATE POLICY audit_isolation ON audit_logs FOR ALL USING (auth.uid() = user_id);
```

