# 07 — AI Systems Architecture & Inference Pipeline

## 1. Executive Summary & AI Integration Principles
The AI subsystem in THOZHI performs two distinct functions:
1. **Speech-to-Text (ASR):** Converts acoustic waveforms of conversational Tanglish, Tamil, or English into text transcripts.
2. **Semantic Extraction & Classification (NLU):** Maps unstructured text into structured, typed Pydantic entities with temporal anchors.

**Architectural Law:**  
The AI subsystem is strictly **perceptual and analytical**. It NEVER solves scheduling algorithms or executes database state changes. Its sole output is a validated, typed data contract passed to the deterministic planning engine.

---

## 2. Speech Recognition (ASR) Subsystem

### 2.1 Abstract ASR Service Interface
To ensure vendor independence and guarantee that THOZHI is never crippled by Gnani account limits, the backend enforces an **Abstract Base Class (ABC)** pattern:

```python
# Conceptual Python Specification (Design Only)
from abc import ABC, abstractmethod
from typing import Dict, Any

class SpeechToTextProvider(ABC):
    @abstractmethod
    async def transcribe(self, audio_bytes: bytes, filename: str = "audio.wav") -> Dict[str, Any]:
        """
        Transcribes audio bytes and returns normalized dictionary:
        {
            "transcript": str,
            "detected_language": str,
            "confidence": float,
            "provider": str
        }
        """
        pass
```

### 2.2 Primary Engine: Gnani.ai Prisma v3.0
- **Endpoint:** `POST https://api.vachana.ai/stt/v3`
- **Authentication:** `X-API-Key-ID: <GNANI_API_KEY>`
- **Request Format:** `multipart/form-data`
  - `audio_file`: Binary WAV stream (16kHz, 16-bit Mono PCM).
  - `model`: `prisma-v3.0`
  - `language_code`: `indic-auto` (or `ta` for explicit Tamil mode).
  - `formatting_mode`: `code-mix` (preserves Latin script for English loanwords).
- **Latency Target:** $\le 1,400\text{ ms}$ for 15 seconds of audio.

### 2.3 Commercial Failover Engine: Sarvam AI Saaras v3
- **Trigger:** Invoked automatically if Gnani returns HTTP 401, 429, 504, or times out after 3.0 seconds.
- **Endpoint:** `POST https://api.sarvam.ai/speech-to-text`
- **Authentication:** `api-subscription-key: <SARVAM_API_KEY>`
- **Request Format:** `multipart/form-data`
  - `file`: Binary WAV stream.
  - `model`: `saaras-v3`
  - `language_code`: `ta-IN`
- **Billing Rate:** ₹30.00 / audio hour (₹0.50 / minute billed per second).

---

## 3. Semantic Extraction & Classification Subsystem

### 3.1 Model Selection & Configuration
- **Model Engine:** **Google Gemini 2.0 Flash** via the official Google GenAI SDK.
- **Inference Parameters:**
  - `temperature = 0.1` (Minimizes creative drift; maximizes deterministic JSON schema compliance).
  - `top_p = 0.95`
  - `response_mime_type = "application/json"`
  - `response_schema = ExtractionResponse` (Enforces Pydantic schema validation at generation time).

### 3.2 Formal Pydantic Extraction Schemas

```python
# Pydantic v2 Schema Specification
from pydantic import BaseModel, Field
from typing import List, Optional
from enum import Enum

class ModalityEnum(str, Enum):
    HARD_COMMITMENT = "HARD_COMMITMENT"
    CASUAL_IDEA = "CASUAL_IDEA"
    WISH = "WISH"
    CONDITIONAL_TASK = "CONDITIONAL_TASK"
    COMPLETED_ACTION = "COMPLETED_ACTION"
    CANCELLED = "CANCELLED"

class PriorityEnum(str, Enum):
    P1_CRITICAL = "P1_CRITICAL"
    P2_MEDIUM = "P2_MEDIUM"
    P3_LOW = "P3_LOW"
    BACKBURNER = "BACKBURNER"

class ExtractedTaskItem(BaseModel):
    temp_id: str = Field(description="Unique incremental string id (e.g., 'task_1')")
    raw_snippet: str = Field(description="Exact substring from input corresponding to this task")
    normalized_title: str = Field(description="Clear, actionable imperative task title in English")
    modality: ModalityEnum = Field(description="Classification of the sentence intention")
    estimated_duration_min: int = Field(default=30, description="Estimated duration in minutes (default 30 if unstated)")
    deadline_expression: Optional[str] = Field(description="Raw temporal expression extracted from text")
    normalized_deadline_iso: Optional[str] = Field(description="ISO-8601 timestamp anchored to the current system date")
    priority_urgency: PriorityEnum = Field(default=PriorityEnum.P2_MEDIUM)
    dependencies: List[str] = Field(default_factory=list, description="List of temp_ids that must complete before this task")
    condition_trigger: Optional[str] = Field(description="Trigger condition if modality is CONDITIONAL_TASK")

class ExtractionResponse(BaseModel):
    intent_summary: str = Field(description="One-sentence English summary of the user's mental monologue")
    detected_language_mix: str = Field(description="e.g. 'Tanglish (Tamil-English)', 'English', 'Tamil'")
    extracted_items: List[ExtractedTaskItem] = Field(description="List of all extracted items")
```

---

## 4. System Prompt Design & Temporal Grounding

```
You are the NLU Engine of THOZHI, an intelligent bilingual personal planning assistant.
Your job is to analyze unstructured spoken or typed thoughts in Tamil, English, or Tanglish 
and extract actionable tasks into strict JSON format.

CURRENT SYSTEM CONTEXT:
- Current Timestamp: {CURRENT_SYSTEM_ISO_TIMESTAMP} (Timezone: Asia/Kolkata)
- Current Day of Week: {CURRENT_DAY_OF_WEEK}

TAXONOMY CLASSIFICATION RULES:
1. HARD_COMMITMENT: Definite obligations, deadlines, promises, deliverables, or meetings.
2. CASUAL_IDEA: Aspirational thoughts, future concepts, uncommitted brainstorming ("maybe I should...").
3. WISH: Desires without immediate intent ("I wish I had time to learn Spanish").
4. CONDITIONAL_TASK: Actions dependent on external triggers ("If Suresh calls, then do X").
5. COMPLETED_ACTION: Tasks explicitly stated as already done ("I already paid the bill").
6. CANCELLED: Tasks explicitly retracted or negated.

TEMPORAL ANCHORING IN TAMIL/TANGLISH:
- "inniku" / "today" -> Calculate against CURRENT_SYSTEM_ISO_TIMESTAMP
- "naalaiki" / "tomorrow" -> CURRENT_DATE + 1 day
- "naalaiki marunaal" / "day after tomorrow" -> CURRENT_DATE + 2 days
- "sayanthiram" / "evening" -> Default to 17:00:00+05:30
- "night kula" -> Default to 21:00:00+05:30
- "adutha vaaram" / "next week" -> Anchor to coming Monday

SELF-REPAIRS AND NEGATIONS:
- If the user corrects themselves mid-stream (e.g. "Thursday 4 PM... wait no, Friday 11 AM"), 
  DISCARD the revoked timestamp (Thursday) and output ONLY the active intent (Friday).
- If the user states "do not schedule X on Wednesday", enforce Wednesday as a negative constraint.
```

---

## 5. Few-Shot Tanglish Extraction Exemplar

### Input:
> *"Naalaiki afternoon 3 PM-ku US client meeting iruku, so before that deck update panni draft anupanum. Tweak panna 2 hours aagum. Also maybe next month tech podcast start pannalaam nu yosikiren. Electricity bill already pay panniten."*

### Model Extraction Output:
```json
{
  "intent_summary": "User preparing for client meeting tomorrow with prerequisite deck work, noting an idea for a podcast, and recording a completed bill payment.",
  "detected_language_mix": "Tanglish (Tamil-English)",
  "extracted_items": [
    {
      "temp_id": "task_1",
      "raw_snippet": "deck update panni draft anupanum. Tweak panna 2 hours aagum",
      "normalized_title": "Update client presentation deck and send draft",
      "modality": "HARD_COMMITMENT",
      "estimated_duration_min": 120,
      "deadline_expression": "before tomorrow 3 PM",
      "normalized_deadline_iso": "2026-11-08T14:30:00+05:30",
      "priority_urgency": "P1_CRITICAL",
      "dependencies": []
    },
    {
      "temp_id": "task_2",
      "raw_snippet": "Naalaiki afternoon 3 PM-ku US client meeting iruku",
      "normalized_title": "Attend US Client Meeting",
      "modality": "HARD_COMMITMENT",
      "estimated_duration_min": 60,
      "deadline_expression": "tomorrow 3 PM",
      "normalized_deadline_iso": "2026-11-08T15:00:00+05:30",
      "priority_urgency": "P1_CRITICAL",
      "dependencies": ["task_1"]
    },
    {
      "temp_id": "task_3",
      "raw_snippet": "maybe next month tech podcast start pannalaam nu yosikiren",
      "normalized_title": "Research and plan tech podcast launch",
      "modality": "CASUAL_IDEA",
      "estimated_duration_min": 30,
      "deadline_expression": "next month",
      "normalized_deadline_iso": null,
      "priority_urgency": "BACKBURNER",
      "dependencies": []
    },
    {
      "temp_id": "task_4",
      "raw_snippet": "Electricity bill already pay panniten",
      "normalized_title": "Pay electricity bill",
      "modality": "COMPLETED_ACTION",
      "estimated_duration_min": 0,
      "deadline_expression": null,
      "normalized_deadline_iso": null,
      "priority_urgency": "P3_LOW",
      "dependencies": []
    }
  ]
}
```

