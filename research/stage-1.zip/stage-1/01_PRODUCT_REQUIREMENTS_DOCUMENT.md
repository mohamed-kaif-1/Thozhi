# 01 — Product Requirements Document (PRD)

## 1. Executive Summary & Document Control
- **Product Name:** THOZHI (Provisional)
- **Document Stage:** Stage 1 — Product & System Architecture
- **Version:** 1.0.0
- **Document Status:** Architectural Specification (Implementation Strictly Prohibited)
- **Primary Stakeholder:** Human Project Owner

THOZHI is an intelligent, voice-first personal planning assistant designed for multilingual contexts (specifically Tamil, English, and Tamil-English code-mixing / Tanglish). It captures unstructured, messy thoughts, identifies real commitments versus casual ideas, validates them against calendar availability using deterministic constraint math, and presents a realistic proposed plan. 

**Foundational Axiom:**  
$$\mathbf{The\ AI\ Proposes.\ The\ User\ Decides.}$$
No task is ever scheduled, shifted, created, or committed to a user's calendar without explicit, single-tap user approval.

---

## 2. Research Traceability Matrix (Stage 0 $\rightarrow$ Stage 1)

This matrix establishes direct bi-directional traceability between Stage 0 research evidence ([`research/stage-0/`](file:///c:/Users/moham/OneDrive - ELCOT/Projects/Thozhi/research/stage-0/README.md)) and Stage 1 product requirements, explicitly preserving epistemological boundaries.

| Stage 0 Finding Ref | Stage 0 Evidence Status | User Problem Identified | Stage 1 Product Requirement (PRD) | Stage 1 Architectural Decision |
| :--- | :--- | :--- | :--- | :--- |
| **S0-FIND-01** (Doc `01`, `06`) | **[FACT]** (Verified via Todoist Language Roster) | Global tools (Todoist Ramble, MS To Do) officially omit Tamil and fail on spoken Tanglish phonetics. | **PRD-REQ-01:** System must natively ingest, transcribe, and parse spoken Tanglish voice input without forcing formal English. | Integrate Gnani Prisma v3 (`POST /stt/v3`, header `X-API-Key-ID`) with Sarvam Saaras API as an active commercial failover. |
| **S0-FIND-02** (Doc `01`, `03`) | **[FACT]** (Kahneman & Tversky, 1979; GTD Theory) | Users conflate casual ideas, conditional wishes, and legal commitments in unstructured thoughts, leading to todo-list paralysis. | **PRD-REQ-02:** System must classify input items into strict modalities (Commitment, Idea, Wish, Conditional, Completed). | Enforce Pydantic strict JSON schema output from Gemini 2.0 Flash (`temperature=0.1`); filter ideas into a non-intrusive backburner archive. |
| **S0-FIND-03** (Doc `06`, `07`) | **[SECONDARY]** (Motion User Reviews & G2 Teardowns) | Autonomous AI auto-reschedulers (Motion) create anxiety and disorientation by moving calendar blocks without asking. | **PRD-REQ-03:** "AI proposes, user decides." System must present an interactive Proposal Card requiring explicit human authorization. | Frontend state machine (Zustand) isolates proposals from `saved_tasks`; database enforces zero write to `saved_tasks` without user approval payload. |
| **S0-FIND-04** (Doc `08`, `17`) | **[FACT]** (LLM Arithmetic Drift Literature) | Autoregressive LLMs cannot reliably solve multi-variable bin-packing; they hallucinate time math and double-book slots. | **PRD-REQ-04:** Planning engine must calculate temporal capacity and dependency validation using deterministic mathematics. | Decouple LLM completely from scheduling: Python backend runs Kahn’s DAG Topological Sort and Interval Deficit Arithmetic. |
| **S0-FIND-05** (Doc `04`, `17`) | **[UNVERIFIED HYPOTHESIS]** (Pending Field Interviews) | Target audience willingness-to-pay (WTP) and habit displacement of WhatsApp self-chat remain unconfirmed. | **PRD-REQ-05:** Architecture must be persona-agnostic and modular to accommodate multiple beachhead groups. | Mark target audience as an open decision; design workflows around universal commitment extraction rather than niche-specific forms. |

---

## 3. Target Audience Reconciliation & Persona Framework

### 3.1 Reconciliation of Target Cohorts
Stage 0 investigated College Students and Freelancers, while early conceptual notes suggested community frontline workers (ASHA healthcare workers). 
To maintain intellectual integrity:
- **ASHA Workers:** Highly empathetic persona, but **completely unvalidated** in field research. ASHA workers operate under state health ministry reporting hierarchies, physical registers, and strict government portal constraints (e.g., RCH portal). Building an unverified consumer app for them risks irrelevance.
- **College Students:** High problem frequency, very low friction, high testing virality, but **near-zero willingness-to-pay**.
- **Freelancers & Solo Consultants:** High cognitive overload, severe financial consequences for dropped commitments, high WTP ($₹299–₹799/\text{mo}$), but high habit inertia from WhatsApp self-chat.

**Architectural Governance Directive:**  
The Stage 1 architecture **DOES NOT hardcode student-specific, corporate-specific, or ASHA-specific logic**. It models **human commitment workflows** generically:
$$\text{Actor} + \text{Spoken Expression} + \text{Commitment} + \text{Duration} + \text{Deadline} + \text{Calendar Space}$$
The final beachhead selection remains an **Unresolved Product Decision** awaiting the human owner's field interviews.

### 3.2 Candidate Personas & User Journeys

```
┌────────────────────────────────────────────────────────────────────────┐
│ Persona A: Karthi — The Bilingual Freelance UI/UX Consultant           │
├────────────────────────────────────────────────────────────────────────┤
│ Context: Juggles 4 client projects, personal life, and tax filings.   │
│ Linguistic Pattern: Spoken Tanglish during commute and walks.          │
│ Pain Point: Commits to a deliverable on Friday without realizing he has│
│             8 hours of meetings on Thursday and zero free slots.       │
│ Core Need: Voice brain-dump that warns him: "You have a 4-hour deficit │
│            on Thursday. Move Client B review to Friday?"              │
└────────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────────┐
│ Persona B: Meena — The Final-Year Engineering Student                  │
├────────────────────────────────────────────────────────────────────────┤
│ Context: Preparing for placement coding rounds, lab records, & exams.  │
│ Linguistic Pattern: Colloquial Tanglish with peer slang.               │
│ Pain Point: Forgets lab record submissions because they were drowned   │
│             inside a 500-message class WhatsApp group.                 │
│ Core Need: Fast 10-second voice dump: "DSP record due tomorrow 4 PM",  │
│            extracting the deadline and placing it on a visual timeline.│
└────────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────────┐
│ Persona C: Selvi — Community Health / Field Coordinator (ASHA Scout)   │
├────────────────────────────────────────────────────────────────────────┤
│ Context: Visits 15 households daily, logs vaccination follow-ups.      │
│ Linguistic Pattern: Pure Tamil dialect with localized medical terms.   │
│ Pain Point: Carrying physical paper registers in the heat; forgetting  │
│             high-risk infant follow-up dates.                          │
│ Core Need: Hands-free spoken Tamil reminder capture on basic Android.  │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Product Value Proposition & Core Workflows

### 4.1 Value Proposition
> *"Speak your mind in Tanglish, Tamil, or English. THOZHI separates your real commitments from casual ideas, mathematically verifies your available calendar time, and proposes a balanced plan. You stay in absolute control."*

### 4.2 The 10-Step Operational Workflow
```
[ Step 1: Ingest Unstructured Input (Audio Speech or Raw Text) ]
                             │
                             ▼
[ Step 2: Speech Recognition (Gnani Prisma v3 / Sarvam Failover) ]
                             │
                             ▼
[ Step 3: NLU Intent Extraction & Modality Classification (Gemini 2.0 Flash) ]
                             │
                             ▼
[ Step 4: Temporal & Dependency Graph Construction (DAG Kahn's Sort) ]
                             │
                             ▼
[ Step 5: Calendar Capacity & Free Window Deficit Calculation ]
                             │
                             ▼
[ Step 6: Conflict Detection & Workload Infeasibility Warning Generation ]
                             │
                             ▼
[ Step 7: Proposal Assembly ("The Proposal Card") ]
                             │
                             ▼
[ Step 8: Interactive User Review (Edit / Reject / Postpone / Clarify) ]
                             │
                             ▼
[ Step 9: Explicit User Approval Execution (PostgreSQL `saved_tasks`) ]
                             │
                             ▼
[ Step 10: Selective Contextual Memory Grounding (User-Governed Retention) ]
```

---

## 5. Feature Prioritization (MoSCoW Framework)

### 5.1 P0: Must-Have (Core MVP Architecture)
1. **Multilingual Audio Capture:** In-browser Web Audio recording (16kHz Mono WAV) and manual text fallback.
2. **ASR Integration:** Abstract ASR service supporting Gnani Prisma v3 and Sarvam Saaras failover.
3. **Intent & Modality Extraction:** Extraction of Commitments, Ideas, Wishes, Conditional Tasks, Completed Tasks, and Deadlines via Gemini 2.0 Flash structured outputs.
4. **Deterministic Constraint Engine:** Kahn's algorithm for DAG task dependencies, calendar working hours calculation, and capacity deficit alerts.
5. **Interactive Proposal Card:** Next.js UI component displaying proposed tasks, durations, conflict badges, inline title/time edits, and an explicit "Approve All" / "Approve Selected" action.
6. **Task Persistence:** Supabase PostgreSQL storage for approved tasks with standard lifecycle states (`PENDING`, `COMPLETED`, `CANCELLED`).
7. **Basic User Auth:** Supabase Auth (Magic Link / Google OAuth) with Row Level Security.

### 5.2 P1: Should-Have (Stage 2 Post-Validation)
1. **One-Way Google Calendar Export:** Push approved tasks as time-blocked events or tasks into the user's Google Calendar.
2. **Audio File Upload:** Allow drag-and-drop of forwarded voice notes (`.m4a`, `.mp3`, `.ogg`).
3. **Conversational Clarification Prompts:** Single-question clarification dialogues when tasks have missing critical deadlines.
4. **Contextual Operational Memory:** Personalized baseline durations (e.g., learning that the user takes 45 minutes for "Reviewing PRs" instead of the default 30 minutes).

### 5.3 P2: Could-Have (Future Roadmap)
1. **Bi-directional Calendar Sync:** Real-time synchronization of busy blocks from Google and Outlook Calendars.
2. **WhatsApp / Telegram Webhook Bot:** Sending audio directly into THOZHI via messaging apps.
3. **Sub-task Decomposition:** One-tap breaking down of overwhelming tasks into micro-steps (Goblin Tools style).

### 5.4 Anti-Scope (Strictly Prohibited in MVP)
- **NO Autonomous Calendar Rescheduling:** System will NEVER move calendar events without user confirmation.
- **NO Proprietary Full Calendar Grid:** THOZHI will not build a full-month/week calendar grid component.
- **NO Team Collaboration / Multi-User Task Assignment:** Strictly a personal single-player tool in MVP.
- **NO Multi-Agent Architectures:** Single deterministic pipeline; no LangChain or multi-agent swarms.

---

## 6. Success Metrics & Acceptance Criteria

| Metric Category | Target Acceptance Threshold | Validation Method |
| :--- | :--- | :--- |
| **ASR Concept Error Rate (CER)** | $\le 10\%$ on Tanglish audio (critical verbs, dates, nouns preserved). | Benchmark on 20 synthetic Tanglish clips (`11-synthetic-test-scenarios.md`). |
| **JSON Schema Syntactic Validity** | $100\%$ schema adherence (zero JSON syntax or type errors). | Pydantic validation on Gemini 2.0 Flash outputs. |
| **Conflict Detection Accuracy** | $100\%$ detection of deterministic mathematical overlaps and circular dependencies. | Unit tests using Kahn's topological sort and interval intersection algorithms. |
| **User Agency Enforcement** | $0$ tasks created in database without an explicit human approval transaction. | Database constraint & RLS audit; automated integration test. |
| **End-to-End Latency Budget** | $\le 3.5\text{s}$ total round-trip from "Stop Speaking" to Proposal Card display. | Network performance logging across 4G/5G connections. |

