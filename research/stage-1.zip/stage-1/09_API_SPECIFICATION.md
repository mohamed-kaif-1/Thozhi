# 09 — API Contracts & OpenAPI 3.1 Specification

## 1. Document Control & Protocol Overview
- **Protocol:** HTTPS RESTful API + JSON
- **Specification Standard:** OpenAPI 3.1.0
- **Base Path:** `/api/v1`
- **Authentication Scheme:** `BearerAuth` (HTTP Authorization header carrying short-lived Supabase JWT).
- **Error Format:** RFC 7807 Problem Details (`application/problem+json`).

---

## 2. Master Endpoint Index

| Method | Path | Summary & Purpose | Auth |
| :--- | :--- | :--- | :---: |
| `POST` | `/api/v1/captures/audio` | Ingests 16kHz WAV audio; returns transcript, parsed entities, and draft proposal. | Required |
| `POST` | `/api/v1/captures/text` | Ingests raw Tanglish/English text; returns parsed entities and draft proposal. | Required |
| `GET` | `/api/v1/proposals/{id}` | Retrieves full proposal card payload, conflict flags, and items. | Required |
| `PATCH`| `/api/v1/proposals/{id}/items/{item_id}` | Inline update of a proposed item's title, duration, or deadline. | Required |
| `POST` | `/api/v1/proposals/{id}/approve` | **The Core Approval Gate:** Converts approved proposals into active tasks. | Required |
| `GET` | `/api/v1/tasks` | Fetches active daily agenda items with date and status filters. | Required |
| `PATCH`| `/api/v1/tasks/{id}` | Updates task execution state (`COMPLETED`, `POSTPONED`, `CANCELLED`). | Required |
| `GET` | `/api/v1/schedule/conflicts` | Queries mathematical capacity deficit and DAG dependencies for a target date. | Required |
| `DELETE`| `/api/v1/memory/priors` | Purges all learned user duration preferences (Right to Erasure). | Required |

---

## 3. Detailed Endpoint Contracts & Payloads

### 3.1 `POST /api/v1/captures/audio`
Ingests binary audio, invokes ASR (Gnani/Sarvam failover), parses intent via Gemini Flash, runs Kahn's math engine, and inserts draft proposal.

- **Headers:** `Authorization: Bearer <JWT>`, `Content-Type: multipart/form-data`
- **Request Body:**
  - `audio_file`: Binary stream (`audio/wav`, 16kHz mono, max 60s, max 5MB).
- **Responses:**
  - **`201 Created`**
    ```json
    {
      "capture_id": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
      "proposal_id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
      "detected_language": "Tanglish (Tamil-English)",
      "asr_provider": "GNANI",
      "raw_transcript": "Naalaiki morning 10 AM-ku client meeting, draft ready pannanum",
      "intent_summary": "User preparing for client meeting tomorrow at 10 AM with prerequisite draft work.",
      "proposed_items": [
        {
          "id": "e4b2d354-9988-466d-a602-53531bcf9012",
          "proposed_title": "Prepare client presentation draft",
          "modality": "HARD_COMMITMENT",
          "estimated_duration_min": 60,
          "target_deadline": "2026-11-08T09:30:00+05:30",
          "priority": "P1_CRITICAL",
          "dependencies": [],
          "conflict_flags": []
        },
        {
          "id": "f5c3e465-1122-477e-b713-64642cd0a123",
          "proposed_title": "Attend client meeting",
          "modality": "HARD_COMMITMENT",
          "estimated_duration_min": 60,
          "target_deadline": "2026-11-08T10:00:00+05:30",
          "priority": "P1_CRITICAL",
          "dependencies": ["e4b2d354-9988-466d-a602-53531bcf9012"],
          "conflict_flags": []
        }
      ],
      "conflict_summary": {
        "has_conflicts": false,
        "total_planned_minutes": 120,
        "available_capacity_minutes": 270,
        "capacity_deficit_minutes": 0,
        "warning_message": null
      }
    }
    ```
  - **`400 Bad Request`**: Malformed audio format or duration exceeds 60 seconds.
  - **`429 Too Many Requests`**: User exceeded 10 audio captures per 10 minutes.
  - **`502 Bad Gateway`**: Both Gnani and Sarvam ASR providers unreachable.

---

### 3.2 `POST /api/v1/captures/text`
Direct text ingestion bypassing speech pipeline.

- **Headers:** `Authorization: Bearer <JWT>`, `Content-Type: application/json`
- **Request Payload:**
  ```json
  {
    "raw_text": "Inniku evening 5 PM doctor checkup, but need to finish GST filing before that (takes 2 hours)."
  }
  ```
- **Responses:** Same payload structure as Section 3.1.

---

### 3.3 `PATCH /api/v1/proposals/{id}/items/{item_id}`
Allows user to modify a proposed task inline prior to clicking Approve.

- **Request Payload:**
  ```json
  {
    "proposed_title": "Finish GST filing for Q2",
    "estimated_duration_min": 90,
    "target_deadline": "2026-11-07T16:00:00+05:30",
    "priority": "P1_CRITICAL"
  }
  ```
- **Response:** `200 OK` with updated `task_proposals` item and recalculated conflict summary.

---

### 3.4 `POST /api/v1/proposals/{id}/approve` (The Human Approval Gate)
Commits user decisions into permanent task storage.

- **Headers:** `Authorization: Bearer <JWT>`, `Content-Type: application/json`
- **Request Payload:**
  ```json
  {
    "idempotency_key": "user_9b1deb_prop_3fa85f_20261107",
    "approved_item_ids": [
      "e4b2d354-9988-466d-a602-53531bcf9012",
      "f5c3e465-1122-477e-b713-64642cd0a123"
    ],
    "rejected_item_ids": [],
    "postponed_item_ids": [],
    "sync_to_google_calendar": true
  }
  ```
- **Backend Transaction:**
  1. Verifies idempotency key (prevents double-booking on laggy connections).
  2. Sets `task_proposals.approval_status = 'APPROVED'`.
  3. Inserts approved items into `saved_tasks`.
- **Response `201 Created`:**
  ```json
  {
    "status": "SUCCESS",
    "created_tasks_count": 2,
    "scheduled_date": "2026-11-08",
    "tasks": [
      {
        "id": "11111111-2222-3333-4444-555555555555",
        "title": "Prepare client presentation draft",
        "scheduled_start": "08:30:00",
        "scheduled_end": "09:30:00",
        "status": "PENDING"
      },
      {
        "id": "66666666-7777-8888-9999-000000000000",
        "title": "Attend client meeting",
        "scheduled_start": "10:00:00",
        "scheduled_end": "11:00:00",
        "status": "PENDING"
      }
    ]
  }
  ```

---

### 3.5 `GET /api/v1/tasks`
Fetches approved tasks for the daily agenda view.

- **Query Parameters:**
  - `date`: ISO date string (default: `CURRENT_DATE`, e.g., `2026-11-07`).
  - `status`: Optional filter (`PENDING`, `COMPLETED`, `ALL`).
- **Response `200 OK`:**
  ```json
  {
    "date": "2026-11-07",
    "total_tasks": 3,
    "completed_tasks": 1,
    "items": [
      {
        "id": "11111111-2222-3333-4444-555555555555",
        "title": "Submit GST return",
        "scheduled_start": "14:00:00",
        "scheduled_end": "15:30:00",
        "duration_min": 90,
        "priority": "P1_CRITICAL",
        "status": "COMPLETED",
        "completed_at": "2026-11-07T15:25:12+05:30"
      }
    ]
  }
  ```

---

### 3.6 `DELETE /api/v1/memory/priors` (Right to Erasure)
Purges all learned user task duration baselines.

- **Response `204 No Content`**

